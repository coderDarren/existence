const getPlayer = require('src/lambda/getPlayer.js');

module.exports = {
    getPlayer
}